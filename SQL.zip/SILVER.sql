
-- =============================================
-- Airbnb Data Warehouse - Silver Layer
-- Purpose: Clean and prepare the raw Airbnb data
-- =============================================

USE AirbnbDW;
GO

-- Create Silver schema if it does not exist
IF NOT EXISTS (
    SELECT 1
    FROM sys.schemas
    WHERE name = 'silver'
)
BEGIN
    EXEC('CREATE SCHEMA silver');
END;
GO

-- Create a cleaned copy of the Bronze data
IF OBJECT_ID('silver.Airbnb_Cleaned', 'U') IS NULL
BEGIN
    SELECT
        NULLIF(LTRIM(RTRIM(Name)), '') AS Name,
        NULLIF(LTRIM(RTRIM(city)), '') AS City,
        Price,
        Superhost,
        is_fav,
        Rating,
        Reviews,
        URL
    INTO silver.Airbnb_Cleaned
    FROM bronze.Airbnb_Raw;
END;
GO

-- Check the number of rows
SELECT COUNT(*) AS Total_Silver_Listings
FROM silver.Airbnb_Cleaned;
GO

-- Preview the cleaned data
SELECT TOP 10 *
FROM silver.Airbnb_Cleaned;
GO



-- Check missing values
SELECT
    SUM(CASE WHEN Name IS NULL THEN 1 ELSE 0 END) AS Missing_Name,
    SUM(CASE WHEN City IS NULL THEN 1 ELSE 0 END) AS Missing_City,
    SUM(CASE WHEN Price IS NULL THEN 1 ELSE 0 END) AS Missing_Price,
    SUM(CASE WHEN Rating IS NULL THEN 1 ELSE 0 END) AS Missing_Rating,
    SUM(CASE WHEN Reviews IS NULL THEN 1 ELSE 0 END) AS Missing_Reviews
FROM silver.Airbnb_Cleaned;
GO

-- Check price range
SELECT
    MIN(Price) AS Minimum_Price,
    MAX(Price) AS Maximum_Price,
    AVG(Price) AS Average_Price
FROM silver.Airbnb_Cleaned;
GO

-- Check duplicate URLs
SELECT
    URL,
    COUNT(*) AS Duplicate_Count
FROM silver.Airbnb_Cleaned
WHERE URL IS NOT NULL
GROUP BY URL
HAVING COUNT(*) > 1;
GO



-- Inspect listings with missing prices
SELECT
    Name,
    City,
    Price,
    Rating,
    Reviews,
    URL
FROM silver.Airbnb_Cleaned
WHERE Price IS NULL;
GO




-- Check invalid prices
SELECT *
FROM silver.Airbnb_Cleaned
WHERE Price IS NOT NULL
  AND Price <= 0;
GO

-- Check ratings outside the expected range
SELECT *
FROM silver.Airbnb_Cleaned
WHERE Rating IS NOT NULL
  AND (Rating < 0 OR Rating > 5);
GO

-- Check negative review counts
SELECT *
FROM silver.Airbnb_Cleaned
WHERE Reviews < 0;
GO




-- Check missing values in all columns
SELECT
    SUM(CASE WHEN Name IS NULL THEN 1 ELSE 0 END) AS Missing_Name,
    SUM(CASE WHEN City IS NULL THEN 1 ELSE 0 END) AS Missing_City,
    SUM(CASE WHEN Price IS NULL THEN 1 ELSE 0 END) AS Missing_Price,
    SUM(CASE WHEN Superhost IS NULL THEN 1 ELSE 0 END) AS Missing_Superhost,
    SUM(CASE WHEN is_fav IS NULL THEN 1 ELSE 0 END) AS Missing_Favorite,
    SUM(CASE WHEN Rating IS NULL THEN 1 ELSE 0 END) AS Missing_Rating,
    SUM(CASE WHEN Reviews IS NULL THEN 1 ELSE 0 END) AS Missing_Reviews,
    SUM(CASE WHEN URL IS NULL THEN 1 ELSE 0 END) AS Missing_URL
FROM silver.Airbnb_Cleaned;
GO






-- Final Silver Layer Validation
SELECT
    COUNT(*) AS Total_Rows,
    COUNT(DISTINCT URL) AS Unique_Listings,
    SUM(CASE WHEN Price IS NULL THEN 1 ELSE 0 END) AS Missing_Prices,
    SUM(CASE WHEN Rating IS NULL THEN 1 ELSE 0 END) AS Missing_Ratings
FROM silver.Airbnb_Cleaned;
GO





USE AirbnbDW;
GO

-- Clean URL values in the existing Silver table
UPDATE silver.Airbnb_Cleaned
SET URL = NULLIF(LTRIM(RTRIM(URL)), '');
GO

-- Verify the result
SELECT
    COUNT(*) AS Total_Rows,
    SUM(CASE WHEN URL IS NULL THEN 1 ELSE 0 END) AS Missing_URLs,
    COUNT(DISTINCT URL) AS Unique_URLs
FROM silver.Airbnb_Cleaned;
GO




USE AirbnbDW;
GO

SELECT TOP 10
    City,
    Price,
    URL
FROM silver.Airbnb_Cleaned
WHERE Price IS NOT NULL
ORDER BY City, Price;





USE AirbnbDW;
GO

SELECT
    COLUMN_NAME,
    DATA_TYPE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = 'silver'
  AND TABLE_NAME = 'Airbnb_Cleaned'
  AND COLUMN_NAME IN ('Price', 'Rating', 'Reviews');
GO
