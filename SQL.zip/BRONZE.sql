
USE AirbnbDW;
GO

-- Create Bronze schema if it does not exist
IF NOT EXISTS (
    SELECT 1
    FROM sys.schemas
    WHERE name = 'bronze'
)
BEGIN
    EXEC('CREATE SCHEMA bronze');
END;
GO

-- Copy raw data into the Bronze layer
IF OBJECT_ID('bronze.Airbnb_Raw', 'U') IS NULL
BEGIN
    SELECT *
    INTO bronze.Airbnb_Raw
    FROM dbo.Airbnb_Scraped_Data;
END;
GO

-- Verify the number of records
SELECT COUNT(*) AS Total_Bronze_Listings
FROM bronze.Airbnb_Raw;
GO

-- Preview the Bronze data
SELECT TOP 10 *
FROM bronze.Airbnb_Raw;
GO
