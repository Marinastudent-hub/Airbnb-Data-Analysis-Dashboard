
-- =============================================
-- Airbnb Data Warehouse - Gold Layer
-- Purpose: Prepare city-level data for Power BI
-- =============================================

USE AirbnbDW;
GO

-- Create Gold schema if it does not exist
IF NOT EXISTS (
    SELECT 1
    FROM sys.schemas
    WHERE name = 'gold'
)
BEGIN
    EXEC('CREATE SCHEMA gold');
END;
GO

-- Create a summary table for each city
IF OBJECT_ID('gold.City_Summary', 'U') IS NOT NULL
    DROP TABLE gold.City_Summary;
GO

SELECT
    City,
    COUNT(*) AS Total_Listings,
    COUNT(Price) AS Listings_With_Price,
    AVG(Price) AS Average_Price,
    MIN(Price) AS Minimum_Price,
    MAX(Price) AS Maximum_Price,
    AVG(Rating) AS Average_Rating,
    SUM(CASE WHEN Superhost = 1 THEN 1 ELSE 0 END) AS Superhost_Count,
    SUM(CASE WHEN is_fav = 1 THEN 1 ELSE 0 END) AS Favorite_Count
INTO gold.City_Summary
FROM silver.Airbnb_Cleaned
GROUP BY City;
GO

-- Preview the result
SELECT *
FROM gold.City_Summary
ORDER BY Total_Listings DESC;
GO




USE AirbnbDW;
GO

SELECT
    SUM(Total_Listings) AS Total_Gold_Listings,
    SUM(Listings_With_Price) AS Listings_With_Price,
    SUM(Superhost_Count) AS Total_Superhosts,
    SUM(Favorite_Count) AS Total_Favorites
FROM gold.City_Summary;
GO




USE AirbnbDW;
GO

-- Create detailed Gold table for Power BI
IF OBJECT_ID('gold.Listing_Details', 'U') IS NOT NULL
    DROP TABLE gold.Listing_Details;
GO

SELECT
    Name,
    City,
    Price,
    Superhost,
    is_fav,
    Rating,
    Reviews,
    URL
INTO gold.Listing_Details
FROM silver.Airbnb_Cleaned;
GO

-- Validate the detailed table
SELECT COUNT(*) AS Total_Gold_Details
FROM gold.Listing_Details;
GO







-- Check Superhost data type
SELECT
    COLUMN_NAME,
    DATA_TYPE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = 'gold'
  AND TABLE_NAME = 'Listing_Details'
  AND COLUMN_NAME = 'Superhost';
GO

-- Check Superhost values and counts
SELECT
    Superhost,
    COUNT(*) AS Listing_Count
FROM gold.Listing_Details
GROUP BY Superhost
ORDER BY Superhost;
GO

-- Check missing Superhost values
SELECT
    COUNT(*) AS Total_Rows,
    SUM(
        CASE
            WHEN Superhost IS NULL THEN 1
            ELSE 0
        END
    ) AS Missing_Superhost
FROM gold.Listing_Details;
GO




